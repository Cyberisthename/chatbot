"""Helper package for Quantacap reporting scripts."""
