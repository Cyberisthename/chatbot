"""Synthetic primitives for Quantacap experiments."""

__all__ = [
    "ZBit",
    "YBit",
    "GGraph",
]
